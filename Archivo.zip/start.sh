node dist/server.js
